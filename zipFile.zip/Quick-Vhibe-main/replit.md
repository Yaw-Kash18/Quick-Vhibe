# Quick Vibe

## Overview

Real-time one-to-one and group messaging web app. pnpm workspace monorepo using TypeScript.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite, Tailwind CSS v4, Framer Motion, Wouter routing, shadcn/ui
- **Auth**: Clerk (via `@clerk/react`, `@clerk/express`)
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec in `lib/api-spec`)

## Artifacts

- `artifacts/quick-vibe` — frontend React app at `/` (port `$PORT`, default 24762)
- `artifacts/api-server` — Express API server at `/api` (port 8080)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec (then fix index files below)
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)

## Database Tables

- `users` — Clerk user ID, username, displayName, avatarUrl, lastSeenAt
- `conversations` — between two users (user1Id, user2Id)
- `messages` — content, senderId, conversationId, isRead, mediaUrl, mediaType, editedAt
- `groups` — name, description, adminOnlyMessaging, createdById
- `group_members` — groupId, userId, isAdmin
- `group_messages` — content, senderId, groupId, mediaUrl, mediaType, editedAt

## API Routes (`/api`)

- `GET /api/users/me` / `PATCH` — get/update own profile
- `GET /api/users/search?q=` — search users
- `POST /api/users/online-status` — heartbeat
- `GET /api/users/online-users` — get online user IDs
- `GET /api/conversations` / `POST` — list/create conversations
- `GET /api/conversations/:id` — get conversation
- `PATCH /api/conversations/:id/read` — mark read
- `GET /api/conversations/:id/messages` / `POST` — list/send messages
- `PATCH /api/conversations/:id/messages/:messageId` — edit DM message
- `POST /api/conversations/:id/typing` — typing indicator
- `GET /api/groups` / `POST` — list/create groups
- `GET /api/groups/:id` / `PATCH` — get/update group (name, description, adminOnlyMessaging)
- `DELETE /api/groups/:id/members/:userId` / `PATCH` — remove/update member role
- `GET /api/groups/:id/messages` / `POST` — list/send group messages
- `PATCH /api/groups/:id/messages/:messageId` — edit group message

## Features Implemented

- DM chat with real-time polling (3s), typing indicators
- Group chat with admin system (promote/demote/remove members)
- Profile picture upload (canvas resize → base64 JPEG)
- **Message editing** — pencil icon on hover for own messages, inline edit, "edited" label
- **Media/file attachments** — Paperclip icon, image resize to 800px, files as base64 data URLs, inline image display, file download cards
- **Group info panel** — edit name/description (all members), admin-only messaging toggle (admins only), member management
- **Admin-only messaging** — when enabled, only group admins can send messages; non-admins see a locked notice
- **Chat backgrounds** — 10 preset backgrounds (gradients + patterns), stored in localStorage per user, set in Settings

## Frontend Pages & Components

- `pages/home.tsx` — landing page
- `pages/sign-in.tsx` / `pages/sign-up.tsx` — Clerk auth pages
- `pages/chat.tsx` — main chat view (protected), background applied to message area
- `pages/settings.tsx` — profile settings + chat background picker
- `components/chat/profile-setup.tsx` — first-time username setup
- `components/chat/sidebar.tsx` — conversation list, user search, unread badges, online status
- `components/chat/conversation-header.tsx` — chat header
- `components/chat/message-list.tsx` — DM messages with inline media, edit, typing indicator
- `components/chat/group-message-list.tsx` — group messages with inline media, edit
- `components/chat/message-input.tsx` — text+emoji+attachment input, admin-only readOnly mode
- `components/chat/group-header.tsx` — group name/members display, opens group-info-panel
- `components/chat/group-info-panel.tsx` — full group management (name/desc/adminOnly/members)
- `components/chat/background-picker.tsx` — 10-slot preset background grid
- `hooks/use-chat-background.ts` — localStorage-backed background state

## Theme

- Dark background: `hsl(240 10% 4%)`
- Primary purple: `hsl(255 85% 65%)`
- Font: Outfit (Google Fonts)

## Important Notes

- After codegen: `lib/api-zod/src/index.ts` must only contain `export * from "./generated/api";`
- After codegen: `lib/api-client-react/src/index.ts` must NOT have the `api.schemas` export line
- Polling: messages/conversations every 3s, heartbeat every 10s, typing every 2s
- Clerk proxy middleware: `artifacts/api-server/src/middleware/clerk-proxy.ts`
- In-memory typing/online store: `artifacts/api-server/src/lib/typingStore.ts`
- Media stored as base64 data URLs in DB (images max 800px JPEG, files up to browser limit)
- Chat backgrounds stored in localStorage key `qv_chat_bg_{userId}`
