import { useEffect, useRef, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  useListMessages, getListMessagesQueryKey, useMarkConversationRead,
  getListConversationsQueryKey, useGetTypingStatus, getGetTypingStatusQueryKey,
  useEditMessage, useToggleReaction,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format, isToday, isYesterday } from "date-fns";
import { Pencil, Check, X, Download, FileIcon } from "lucide-react";
import { useLongPress } from "@/hooks/use-long-press";
import { useEmojiUsage } from "@/hooks/use-emoji-usage";
import ReactionPicker from "./reaction-picker";
import type { CSSProperties } from "react";

interface User { id: number; username: string; displayName: string | null; avatarUrl: string | null; }
interface Reaction { emoji: string; count: number; userIds: number[]; }
interface MessageListProps { conversationId: number; currentUser: User; backgroundStyle?: CSSProperties; }

function TypingDots() {
  return (
    <div className="flex items-center gap-1 px-1">
      {[0, 1, 2].map((i) => (
        <motion.div key={i} className="h-2 w-2 rounded-full bg-muted-foreground/60" animate={{ y: ["0%", "-50%", "0%"] }} transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15, ease: "easeInOut" }} />
      ))}
    </div>
  );
}

function formatMessageTime(date: Date): string {
  if (isToday(date)) return format(date, "h:mm a");
  if (isYesterday(date)) return `Yesterday ${format(date, "h:mm a")}`;
  return format(date, "MMM d, h:mm a");
}

function MediaDisplay({ url, type, name }: { url: string; type: string; name?: string }) {
  if (type.startsWith("image/")) {
    return <img src={url} alt="attachment" className="max-w-[240px] max-h-[300px] rounded-xl object-cover mt-1 cursor-pointer" onClick={() => window.open(url, "_blank")} />;
  }
  return (
    <a href={url} download={name ?? "file"} className="flex items-center gap-2 bg-black/20 rounded-xl px-3 py-2 mt-1 hover:bg-black/30 transition-colors">
      <FileIcon className="h-4 w-4 flex-shrink-0" />
      <span className="text-xs truncate max-w-[180px]">{name ?? "Download file"}</span>
      <Download className="h-3.5 w-3.5 flex-shrink-0 opacity-70" />
    </a>
  );
}

function ReactionPills({ reactions, currentUserId, onToggle }: { reactions: Reaction[]; currentUserId: number; onToggle: (emoji: string) => void }) {
  if (reactions.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1 mt-1.5">
      {reactions.map((r) => {
        const mine = r.userIds.includes(currentUserId);
        return (
          <motion.button
            key={r.emoji}
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => onToggle(r.emoji)}
            className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border transition-colors select-none ${mine ? "bg-primary/15 border-primary/40 text-primary" : "bg-muted/50 border-border/30 hover:bg-muted text-foreground"}`}
          >
            <span className="text-base leading-none">{r.emoji}</span>
            <span className="font-medium tabular-nums">{r.count}</span>
          </motion.button>
        );
      })}
    </div>
  );
}

function MessageBubble({ msg, isMine, isGrouped, isLast, currentUser, conversationId, onEditStart, isEditing, editContent, setEditContent, onEditSave, onEditCancel, topEmojis, onRecord }: {
  msg: any; isMine: boolean; isGrouped: boolean; isLast: boolean;
  currentUser: User; conversationId: number;
  onEditStart: (id: number, content: string) => void;
  isEditing: boolean; editContent: string; setEditContent: (v: string) => void;
  onEditSave: () => void; onEditCancel: () => void;
  topEmojis: string[]; onRecord: (emoji: string) => void;
}) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const [hoveredEdit, setHoveredEdit] = useState(false);
  const queryClient = useQueryClient();
  const toggleReaction = useToggleReaction();
  const editRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => { if (isEditing && editRef.current) { editRef.current.focus(); editRef.current.select(); } }, [isEditing]);

  const openPicker = useCallback(() => setPickerOpen(true), []);
  const longPress = useLongPress(openPicker, 480);

  const handleReaction = (emoji: string) => {
    onRecord(emoji);
    setPickerOpen(false);
    toggleReaction.mutate(
      { id: conversationId, messageId: msg.id, data: { emoji } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListMessagesQueryKey(conversationId, {}) }) }
    );
  };

  const hasMedia = !!msg.mediaUrl;
  const hasText = !!msg.content;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      className={`flex items-end gap-2 ${isMine ? "flex-row-reverse" : "flex-row"} ${isGrouped ? "mt-0.5" : "mt-3"} group`}
      data-testid={`message-${msg.id}`}
    >
      {!isMine && (
        <div className="w-7 flex-shrink-0">
          {isLast && (
            <Avatar className="h-7 w-7">
              <AvatarImage src={msg.sender.avatarUrl ?? undefined} />
              <AvatarFallback className="bg-muted text-muted-foreground text-xs">{(msg.sender.displayName || msg.sender.username).charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
          )}
        </div>
      )}

      <div className={`max-w-[70%] ${isMine ? "items-end" : "items-start"} flex flex-col relative`}>
        {isEditing ? (
          <div className="flex flex-col gap-1 w-64">
            <textarea ref={editRef} className="w-full bg-muted/60 border border-primary/50 rounded-xl px-3 py-2 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-primary/50" value={editContent} onChange={(e) => setEditContent(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); onEditSave(); } if (e.key === "Escape") onEditCancel(); }} rows={2} />
            <div className="flex justify-end gap-1">
              <button onClick={onEditCancel} className="h-7 w-7 flex items-center justify-center rounded-full bg-muted hover:bg-muted/80 text-muted-foreground transition-colors"><X className="h-3.5 w-3.5" /></button>
              <button onClick={onEditSave} className="h-7 w-7 flex items-center justify-center rounded-full bg-primary hover:bg-primary/80 text-primary-foreground transition-colors"><Check className="h-3.5 w-3.5" /></button>
            </div>
          </div>
        ) : (
          <div className="relative">
            {/* Reaction picker floats above this */}
            <ReactionPicker open={pickerOpen} isMine={isMine} topEmojis={topEmojis} onSelect={handleReaction} onClose={() => setPickerOpen(false)} />

            <div className={`flex items-end gap-1.5 ${isMine ? "flex-row-reverse" : ""}`}>
              {isMine && (
                <button
                  onMouseEnter={() => setHoveredEdit(true)} onMouseLeave={() => setHoveredEdit(false)}
                  onClick={() => onEditStart(msg.id, msg.content)}
                  className={`h-6 w-6 flex items-center justify-center rounded-full bg-muted/80 text-muted-foreground hover:text-foreground transition-all flex-shrink-0 ${hoveredEdit ? "opacity-100" : "opacity-0 group-hover:opacity-100"}`}
                  title="Edit message"
                >
                  <Pencil className="h-3 w-3" />
                </button>
              )}
              <div
                {...longPress}
                className={`px-3.5 py-2 rounded-2xl text-sm leading-relaxed cursor-pointer select-none ${isMine ? "bg-primary text-primary-foreground rounded-br-sm" : "bg-muted text-foreground rounded-bl-sm"} ${isGrouped && !isMine ? "rounded-tl-md" : ""} ${isGrouped && isMine ? "rounded-tr-md" : ""}`}
              >
                {hasText && <span>{msg.content}</span>}
                {hasMedia && <MediaDisplay url={msg.mediaUrl} type={msg.mediaType ?? ""} name={msg.content || undefined} />}
              </div>
            </div>

            <ReactionPills reactions={msg.reactions ?? []} currentUserId={currentUser.id} onToggle={handleReaction} />
          </div>
        )}

        {isLast && !isEditing && (
          <span className={`text-[10px] text-muted-foreground/50 mt-1 px-1 flex items-center gap-1 ${isMine ? "flex-row-reverse" : ""}`}>
            {formatMessageTime(new Date(msg.createdAt))}
            {msg.editedAt && <span className="text-[9px] opacity-60 flex items-center gap-0.5"><Pencil className="h-2 w-2" />edited</span>}
          </span>
        )}
      </div>
    </motion.div>
  );
}

export default function MessageList({ conversationId, currentUser, backgroundStyle }: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editContent, setEditContent] = useState("");
  const { recordUsage, getTopEmojis } = useEmojiUsage(currentUser.id);
  const topEmojis = getTopEmojis(5);

  const { data: messages = [], isLoading } = useListMessages(conversationId, {}, {
    query: { queryKey: getListMessagesQueryKey(conversationId, {}), refetchInterval: 3000, enabled: !!conversationId },
  });

  const { data: typingStatuses = [] } = useGetTypingStatus({
    query: { queryKey: getGetTypingStatusQueryKey(), refetchInterval: 2000 },
  });

  const editMessage = useEditMessage();
  const markRead = useMarkConversationRead();

  useEffect(() => {
    markRead.mutate({ id: conversationId }, { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() }) });
  }, [conversationId]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages.length]);

  const startEdit = (msgId: number, content: string) => { setEditingId(msgId); setEditContent(content); };
  const cancelEdit = () => { setEditingId(null); setEditContent(""); };
  const saveEdit = (msgId: number) => {
    if (!editContent.trim()) return;
    editMessage.mutate(
      { id: conversationId, messageId: msgId, data: { content: editContent.trim() } },
      { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListMessagesQueryKey(conversationId, {}) }); setEditingId(null); } }
    );
  };

  const typingStatus = typingStatuses.find((t) => t.conversationId === conversationId);
  const isOtherTyping = (typingStatus?.typingUserIds ?? []).filter((id) => id !== currentUser.id).length > 0;

  if (isLoading) {
    return <div className="flex-1 flex items-center justify-center"><div className="h-5 w-5 rounded-full border-2 border-primary border-t-transparent animate-spin" /></div>;
  }

  return (
    <div className="flex-1 overflow-y-auto px-4 py-4 space-y-1" style={backgroundStyle} data-testid="message-list">
      {messages.length === 0 && (
        <div className="flex items-center justify-center h-full">
          <p className="text-sm text-muted-foreground">No messages yet. Say hello!</p>
        </div>
      )}

      <AnimatePresence initial={false}>
        {messages.map((msg, i) => {
          const isMine = msg.senderId === currentUser.id;
          const prevMsg = messages[i - 1];
          const isGrouped = prevMsg?.senderId === msg.senderId;
          const isLast = !messages[i + 1] || messages[i + 1].senderId !== msg.senderId;
          return (
            <MessageBubble
              key={msg.id}
              msg={msg}
              isMine={isMine}
              isGrouped={isGrouped}
              isLast={isLast}
              currentUser={currentUser}
              conversationId={conversationId}
              onEditStart={startEdit}
              isEditing={editingId === msg.id}
              editContent={editContent}
              setEditContent={setEditContent}
              onEditSave={() => saveEdit(msg.id)}
              onEditCancel={cancelEdit}
              topEmojis={topEmojis}
              onRecord={recordUsage}
            />
          );
        })}
      </AnimatePresence>

      <AnimatePresence>
        {isOtherTyping && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} transition={{ duration: 0.2 }} className="flex items-end gap-2 mt-2">
            <div className="w-7" />
            <div className="bg-muted rounded-2xl rounded-bl-sm px-3.5 py-2.5"><TypingDots /></div>
          </motion.div>
        )}
      </AnimatePresence>
      <div ref={bottomRef} />
    </div>
  );
}
