import { Link } from "wouter";
import { ArrowLeft, Settings } from "lucide-react";
import { useGetConversation, getGetConversationQueryKey, useGetOnlineUsers, getGetOnlineUsersQueryKey } from "@workspace/api-client-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

interface ConversationHeaderProps {
  conversationId: number;
  onBack?: () => void;
}

export default function ConversationHeader({ conversationId, onBack }: ConversationHeaderProps) {
  const { data: conversation } = useGetConversation(conversationId, {
    query: {
      queryKey: getGetConversationQueryKey(conversationId),
      enabled: !!conversationId,
      refetchInterval: 5000,
    },
  });

  const { data: onlineData } = useGetOnlineUsers({
    query: {
      queryKey: getGetOnlineUsersQueryKey(),
      refetchInterval: 10000,
    },
  });

  const onlineUserIds = onlineData?.onlineUserIds ?? [];
  const isOnline = conversation ? onlineUserIds.includes(conversation.otherUser.id) : false;

  if (!conversation) {
    return (
      <div className="h-14 border-b border-border/30 bg-card/80 backdrop-blur-sm flex items-center px-4 gap-2 flex-shrink-0">
        {onBack && (
          <button onClick={onBack} className="md:hidden mr-1 text-muted-foreground hover:text-foreground transition-colors p-1 -ml-1">
            <ArrowLeft className="h-5 w-5" />
          </button>
        )}
        <div className="h-8 w-32 bg-muted/50 rounded animate-pulse" />
      </div>
    );
  }

  const displayName = conversation.otherUser.displayName || conversation.otherUser.username;
  const initials = displayName.charAt(0).toUpperCase();

  return (
    <div
      className="h-14 border-b border-border/30 bg-card/80 backdrop-blur-sm flex items-center px-3 sm:px-4 gap-2 sm:gap-3 flex-shrink-0"
      data-testid="conversation-header"
    >
      {/* Back button — mobile only */}
      {onBack && (
        <button
          onClick={onBack}
          className="md:hidden flex-shrink-0 text-muted-foreground hover:text-foreground transition-colors p-1.5 -ml-1.5 rounded-lg hover:bg-muted/50"
          aria-label="Back to conversations"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
      )}

      <div className="relative flex-shrink-0">
        <Avatar className="h-9 w-9">
          <AvatarImage src={conversation.otherUser.avatarUrl ?? undefined} />
          <AvatarFallback className="bg-primary/10 text-primary text-sm">
            {initials}
          </AvatarFallback>
        </Avatar>
        {isOnline && (
          <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-green-500 ring-2 ring-card" />
        )}
      </div>

      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold truncate">{displayName}</p>
        <p className="text-xs text-muted-foreground">
          {isOnline ? (
            <span className="text-green-500">Online</span>
          ) : (
            `@${conversation.otherUser.username}`
          )}
        </p>
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="h-9 w-9 text-muted-foreground hover:text-foreground flex-shrink-0"
        asChild
      >
        <Link href="/settings">
          <Settings className="h-4 w-4" />
        </Link>
      </Button>
    </div>
  );
}
